define(["ScrollMagic", "ScrollMagic/jquery.ScrollMagic"], function (ScrollMagic) {
	describe("", function() {
		xit("has method 'setTween'", function () {
			
		});
	});
});