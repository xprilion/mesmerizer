# mesmerizer
The website for the cultural fest mesmerizer
